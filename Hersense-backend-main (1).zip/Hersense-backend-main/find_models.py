import google.generativeai as genai

# Replace with your real key
genai.configure(api_key="AIzaSyBdcHV4S-GOahcjs9Xz2MY77fH4Qz_nwio")

print("--- Checking Available Models ---")
try:
    for m in genai.list_models():
        if 'generateContent' in m.supported_generation_methods:
            print(f"✅ Found: {m.name}")
except Exception as e:
    print(f"❌ Error: {e}")