from fastapi import FastAPI, UploadFile, File, Form
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from datetime import datetime
from google import genai
from google.genai import types
from typing import Optional, List
from fpdf import FPDF
from fastapi.responses import FileResponse
import uvicorn
import os
import json
import csv
import random

# --- 1. INITIALIZATION ---
app = FastAPI(title="HerSense AI Intelligence Engine")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"], 
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

client = genai.Client(api_key="AIzaSyCllo1somo5NsTwD-DaxVs-v849QSKv77I")
MODEL_ID = "gemini-2.0-flash" 
HISTORY_FILE = "user_history.json"
DATA_CSV = "her_sense_data.csv"
SKIN_CSV = "skin.csv"

# --- 2. DATA-HEAVY KNOWLEDGE VAULT ---
PHASE_INTEL = {
    "menstrual": {
        "nutrition": "🩸 Iron & Magnesium Focus: Your iron levels are dipping. Incorporate spinach, dark chocolate (85%+), and lentils to combat fatigue. Focus on Vitamin C to aid iron absorption. Avoid cold foods; opt for warm, grounding soups and bone broths.",
        "fitness": "🧘 Restorative Flow: Focus on 'Flow over Force'. Your joints are lax right now; avoid heavy weights. Suggesting Yin Yoga, deep pelvic stretching, or light 15-min walking to move stagnant energy.",
        "forecast": "🌑 Low Tide Protocol: Estrogen and Progesterone are at their lowest. Expect lower physical stamina but higher intuitive clarity. Your brain is wired for reflection. Ideal for journaling.",
        "partner": "I'm in my Menstrual phase. My energy is at its lowest and I'm focusing on recovery. I'd appreciate some extra rest and maybe a warm meal tonight.",
        "match_explanation": "Perfect for Menstrual phase. This formula avoids harsh actives while the skin barrier is most sensitive.",
        "period_meta": {
            "status": "Active", "days_remaining": 3, "intensity_alert": "Heavy flow likely due to recent stress levels.", "action": "Increase Magnesium intake to 400mg tonight."
        }
    },
    "follicular": {
        "nutrition": "🌱 Fermented Foods & Zinc: Estrogen is rising, boosting your metabolism. Support gut health with kimchi, sauerkraut, or Greek yogurt.",
        "fitness": "⚡ High Intensity: Estrogen is building your muscle-building capacity. Optimal for HIIT or heavy lifting.",
        "forecast": "☀️ Rising Sun: Estrogen is climbing rapidly. Your brain's verbal and social centers are peaking.",
        "partner": "I'm in my Follicular phase! My energy and mood are rising. Let's plan a fun outing!",
        "match_explanation": "Great match. This phase supports active ingredients as skin resilience is increasing."
    },
    "ovulation": {
        "nutrition": "🍓 Fiber & Anti-inflammatory: Support your liver in processing the estrogen peak. Focus on raw cruciferous veggies.",
        "fitness": "🔥 Peak Performance: Physical strength is at its absolute maximum. Go for your personal bests (PRs) today.",
        "forecast": "💎 Zenith: Testosterone and Estrogen peak together. You likely feel most confident and energetic.",
        "partner": "I'm Ovulating! I'm feeling my most energetic and confident.",
        "match_explanation": "98% Match. Excellent for managing the slight sebum increase during the LH surge."
    },
    "luteal": {
        "nutrition": "🥔 Complex Carbs & Healthy Fats: Your metabolism increases. Opt for sweet potatoes and avocados to stabilize blood sugar.",
        "fitness": "🚶 LISS: Progesterone increases body temperature. Focus on reducing inflammation with Pilates or swimming.",
        "forecast": "⚠️ Storm Alert: Progesterone drop expected tomorrow. Likely symptoms: Irritability and brain fog.",
        "partner": "I'm in my Luteal phase. My body is working harder and burning more calories. I appreciate some patience today.",
        "match_explanation": "Match: 92%. Contains actives like Salicylic Acid to fight progesterone-induced acne."
    }
}

# --- 3. MODELS & UTILITIES ---
class UpdateRequest(BaseModel):
    phase: str
    last_period: str

class AlertRequest(BaseModel):
    contact_name: str
    location: str

class InsightEntry(BaseModel):
    stress: int
    energy: int
    mood: str
    symptoms: List[str]
    timestamp: Optional[str] = None

def save_to_memory(entry):
    history = []
    if os.path.exists(HISTORY_FILE):
        with open(HISTORY_FILE, "r") as f:
            try: history = json.load(f)
            except: history = []
    history.append(entry)
    with open(HISTORY_FILE, "w") as f:
        json.dump(history[-50:], f, indent=4)

def get_csv_bio_data(phase_query: str):
    phase_info = {}
    try:
        if os.path.exists(DATA_CSV):
            with open(DATA_CSV, mode='r', encoding='utf-8') as f:
                reader = csv.DictReader(f)
                for row in reader:
                    if phase_query.lower() in row.get('phase_name', '').lower():
                        phase_info = row
                        break
    except Exception: pass
    return phase_info

# --- 4. HIGH-END DYNAMIC SKINCARE ENGINE ---
@app.get("/engine/care-hub/skincare-protocol")
async def get_skincare_protocol(phase: str, temp: int, uv: float, humidity: int):
    p = phase.lower()
    res = {
        "cleanser": "Gentle pH-Balanced Milk Cleanser",
        "serum": "Hyaluronic Acid + Vitamin B5",
        "moisturizer": "Ceramide-Rich Barrier Gel",
        "spf_required": "SPF 30 Broad Spectrum",
        "barrier_status": "STABLE",
        "special_note": "Your biology is in balance. Maintain standard hydration.",
        "uv_index": uv,
        "temp": f"{temp}°C"
    }
    if humidity < 40 or temp < 20:
        res.update({
            "cleanser": "Non-Foaming Cream Cleanser",
            "moisturizer": "Lipid-Replenishing Thick Cream",
            "barrier_status": "VULNERABLE (Dryness Risk)",
            "special_note": "Dry air detected. Focus on barrier repair and lipid locking."
        })
        if p == "menstrual":
            res["serum"] = "Polyglutamic Acid (Deep Moisture Recovery)"
    elif temp > 28 or humidity > 70:
        res.update({
            "cleanser": "Salicylic Acid (2% BHA) Foaming Wash",
            "moisturizer": "Oil-Free Ultra Light Water-Gel",
            "special_note": "High heat detected. Use non-comedogenic formulas to prevent clogged pores."
        })
        if p == "luteal":
            res["serum"] = "10% Niacinamide + Zinc PCA (Oil Control)"
    if uv > 5.0:
        res["spf_required"] = "SPF 50+ PA++++ (Tinted Mineral suggested)"
        res["serum"] = "Stable Vitamin C (L-Ascorbic Acid) + Ferulic Acid"
        if p == "ovulation":
            res["special_note"] = "Pigmentation Risk: Estrogen peaks today. Reapply SPF every 2 hours."
    return res

# --- 5. INSIGHT & TREND ENDPOINTS ---
@app.get("/engine/insight/history")
async def get_history():
    if os.path.exists(HISTORY_FILE):
        with open(HISTORY_FILE, "r") as f:
            return json.load(f)
    return []

@app.get("/engine/insight/trends")
async def get_trends():
    return {
        "pattern": "Stable luteal phase variance detected.",
        "recommendation": "Increase sleep by 45 mins during menstrual transition."
    }

@app.get("/engine/insight/forecast")
async def get_forecast(phase: str):
    intel = PHASE_INTEL.get(phase.lower(), PHASE_INTEL["menstrual"])
    return {"forecast": intel["forecast"]}

@app.get("/engine/insight/partner-sync")
async def get_partner_sync(phase: str):
    intel = PHASE_INTEL.get(phase.lower(), PHASE_INTEL["menstrual"])
    return {"message": intel["partner"]}

# --- 6. SOS, STATUS & UPDATE ENDPOINTS ---
@app.get("/engine/sos/doctors")
async def get_nearby_doctors():
    return [{"name": "Dr. Sarah Khan (OB-GYN)", "distance": "0.8 km", "contact": "+91 98480 22338", "status": "Open"}]

@app.post("/engine/update")
async def update_engine(data: UpdateRequest):
    return {"status": "success", "message": f"Engine updated to {data.phase}."}

@app.get("/engine/cycle/status")
async def get_cycle_status(phase: str):
    p = phase.lower()
    if p == "menstrual":
        return PHASE_INTEL["menstrual"]["period_meta"]
    return {"status": "Active", "days_remaining": 0, "intensity_alert": "N/A", "action": "N/A"}

@app.get("/engine/care-hub")
async def get_care_hub_intelligence(phase: str):
    p = phase.lower()
    intel = PHASE_INTEL.get(p, PHASE_INTEL["menstrual"])
    return {"diet": intel["nutrition"], "fitness": intel["fitness"]}

@app.get("/engine/care-hub/clinical-prediction")
async def predict_risk():
    if not os.path.exists(HISTORY_FILE):
        return {"condition": "Insufficient Data", "insight": "Log symptoms to unlock AI scanning."}
    return {"condition": "Biological Homeostasis", "insight": "Hormonal patterns appear stable.", "med_note": "No clinical flags detected."}

@app.get("/engine/care-hub/symptom-fix")
async def get_symptom_fix(phase: str, symptom: str):
    s_map = {"cramps": {"desi": "Warm Ajwain water.", "western": "Magnesium Glycinate."}}
    return s_map.get(symptom.lower(), {"desi": "Herbal infusion.", "western": "Check vitals."})

@app.post("/engine/insight/log")
async def log_insight(data: InsightEntry):
    entry = data.dict()
    entry["timestamp"] = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    save_to_memory(entry)
    return {"status": "success"}

@app.get("/engine/generate-report")
async def generate_pdf_report():
    return FileResponse(path="clinical_report.pdf", filename="HerSense_Report.pdf")

if __name__ == "__main__":
    uvicorn.run(app, host="0.0.0.0", port=8000)